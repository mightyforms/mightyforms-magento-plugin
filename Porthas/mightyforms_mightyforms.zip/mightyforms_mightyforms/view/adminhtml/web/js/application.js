
require(['jquery'], function ($) {

    $(document).ready(function () {
        $('#mightyforms').css('height', $(window).height());
    });

})